import React from 'react'

const Progress = ({titlle, procent, wgProcent, procentText}) => {
  return (
    <div className='prog d-flex w-100'>
        <p className='p-0 m-0'>{titlle}</p>
      <div className='progress w-100 mx-3' role='progressbar' aria-label='Basic example' aria-valuenow={procent}
          aria-valuemin={0} aria-valuemax={100}>
          <div className="progress-bar" style={{width: `${wgProcent}`, borderRadius: "20px"}}>
          </div>
      </div>
      {procentText}
  </div>

  )
}

export default Progress
