import React from 'react'
import { MDBContainer } from "mdbreact"; 
import { Doughnut } from "react-chartjs-2";
import {Chart, ArcElement} from 'chart.js' 

const Charts = ({data}) => {
    Chart.register(ArcElement);
  return (
    
    <Doughnut data={data}  />  
  )
}

export default Charts
