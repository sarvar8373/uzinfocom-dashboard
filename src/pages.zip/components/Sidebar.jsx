import React from 'react'
import {Navbar} from 'react-bootstrap';
import Nav from 'react-bootstrap/Nav';
import img from '../assets/logo.png'
import img2 from '../assets/Vector.png'
import {RxDashboard} from "react-icons/rx";
import {PiMapPinLineLight, PiSuitcaseLight, PiDoorLight} from "react-icons/pi";

const Sidebar = () => {
    return (
        <Nav
            defaultActiveKey="/home"
            className="flex-column justify-content-between flex-nowrap"
            style={{
            height: "100%"
        }}>
            <div >
                <Navbar.Brand className='side' href="#home">
                    <img
                        src={img}
                        width="118"
                        height="56"
                        className="d-inline-block align-top"
                        alt="React Bootstrap logo"/>
                </Navbar.Brand>
                <div className='links'>
                    <Nav.Link className='lnk ps-0' href="/" active>
                        <div className='side'><RxDashboard className='icon' width={26} height={26}/> Umumiy statistika</div>
                    </Nav.Link>
                    <Nav.Link className='lnk ps-0' eventKey="link-1">
                        <div className='side'><PiMapPinLineLight className='icon' width={26} height={26}/> Hududlar kesimida</div>
                    </Nav.Link>
                    <Nav.Link className='lnk ps-0' eventKey="link-2">
                        <div className='side'><PiSuitcaseLight className='icon' width={26} height={26}/> Sohalar kesimida</div>
                    </Nav.Link>
                    <Nav.Link className='lnk ps-0' eventKey="link-3">
                        <div className='side'><PiDoorLight className='icon' width={26} height={26}/> Tashkilotlar kesimida</div>
                    </Nav.Link>
                </div>

            </div>

            <img
                src={img2}
                // width="100%"
                // height="250"
                className="d-inline-block align-top"
                alt="React Bootstrap logo"/>
        </Nav>
    )
}

export default Sidebar