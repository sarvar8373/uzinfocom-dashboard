import React from 'react'

const ChartNumber = ({title, procent, number}) => {
  return (
    <div>
     <div className='titles d-flex'>
         <div className='mid-circle me-1'></div>
         <h5 className=''>{title}</h5> <span className='ms-1' style={{ color: "#05CD99" }}>{procent}</span>

     </div>
     <h4>{number}</h4>
 </div>                                             
  )
}

export default ChartNumber
