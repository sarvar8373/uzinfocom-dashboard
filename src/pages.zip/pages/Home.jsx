import React from 'react'
import { Breadcrumb, Button, Col } from 'react-bootstrap'
import { GoSun } from "react-icons/go";
import { FaRegCalendar } from "react-icons/fa";
import img from '../assets/message.png'
import img2 from '../assets/map.png'
import img3 from '../assets/Union.png'
import { LuLandmark } from "react-icons/lu";
import Progress from '../components/Progress';
import { TfiStatsUp } from "react-icons/tfi";
import Charts from '../components/Charts';
import ChartNumber from '../components/ChartNumber';
import Table from '../components/Table';

const Home = () => {

const data = {
labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
datasets: [
{
label: "Hours Studied in Geeksforgeeks",
data: [3, 1, 2 ],
backgroundColor: ["#0183C6", "#42BCFB", "#E5EAF1"],
cutout: 130,
radius: 80,

}
]
}
return (
<div>
    <div className='head d-flex flex-wrap justify-content-between'>
        <div>
            <Breadcrumb>
                <Breadcrumb.Item active>Pages</Breadcrumb.Item>
                <Breadcrumb.Item active>Umumiy statistika</Breadcrumb.Item>
            </Breadcrumb>
            <h2>Asosiy Dashboard</h2>
        </div>
        <div>
            <Button className='bg-light border-0 text-primary my-4'>
                <GoSun /></Button>
            <Button className='bg-light border-0 text-secondary'>
                <FaRegCalendar />
                mm/dd/2023</Button>
        </div>
    </div>
    <div className='cards d-flex flex-wrap'>
        <div>
            <Col className='card d-flex justify-content-between flex-wrap border-0'>
            <div className='d-flex flex-wrap'>

                <div>
                    <h3 className='card-title'>Murojaatlar soni</h3>
                    <p className='card-text text-secondary'>Barcha murojaatlar</p>
                    <Charts data={data} />

                </div>
                <div className='card-image px-2 py-3'>
                    <img src={img} alt="" />
                </div>
                <div className='card border-0 wth'>
                    <ChartNumber title="Yangi" procent="15%" number="120 350" />
                    <ChartNumber title="Jarayonda" procent="75%" number="120 350" />
                    <ChartNumber title="Ko'rib chiqilgan" procent="35%" number="120 350" />
                </div>
            </div>

            </Col>
        </div>
        <div>
            <Col className='card border-0'>
            <div className='d-flex justify-content-between flex-wrap'>
                <div>
                    <h3 className='card-title'>Hududlar kesimida eng ko’p murojaatlar</h3>
                    <div className='card-groups'>
                        <Col className='colum d-flex'>
                        <span className='circle me-2'>1832</span>
                        <p className='group-text'>1832 ming murojaat surxondaryo <br />viloyatidan</p>
                        </Col>
                        <Col className='colum d-flex'>
                        <span className='circle me-2' style={{background: "#4318FF"}}>1832</span>
                        <p className='group-text'>1832 ming murojaat surxondaryo <br />viloyatidan</p>
                        </Col>
                        <Col className='colum d-flex'>
                        <span className='circle me-2' style={{background: "#18D5FF"}}>1832</span>
                        <p className='group-text'>1832 ming murojaat surxondaryo <br />viloyatidan</p>
                        </Col>
                    </div>

                </div>

                <img src={img2} alt="" className='card-image px-2 py-3' />
            </div>
            </Col>
        </div>
        <div>
            <Col className='card border-0' xs={5} style={{width: "700px"}}>
            <div className='d-flex justify-content-between flex-wrap'>
                <div>
                    <h3 className='card-title'>Kelib tushgan murojaatlarda eng ko’p kotarilgan masalalar</h3>
                    {/*
                    <Doughnut data={data} /> */}

                </div>
                <div className='w-100 pb-2'>
                    <Progress titlle={"Uy joy bilan taminlash"} procent={25} wgProcent={"25%"} procentText={"23.28%"} />
                    <Progress titlle={"Prezident shaxsiy qabuli"} procent={35} wgProcent={"35%"}
                        procentText={"23.28%"} />
                    <Progress titlle={"Uy joy bilan taminlash"} procent={45} wgProcent={"45%"} procentText={"23.28%"} />
                    <Progress titlle={"Uy joy bilan taminlash"} procent={55} wgProcent={"55%"} procentText={"23.28%"} />
                    <Progress titlle={"Uy joy bilan taminlash"} procent={65} wgProcent={"65%"} procentText={"23.28%"} />
                    <Progress titlle={"Uy joy bilan taminlash"} procent={65} wgProcent={"65%"} procentText={"23.28%"} />
                    <Progress titlle={"Uy joy bilan taminlash"} procent={65} wgProcent={"65%"} procentText={"23.28%"} />
                    <Progress titlle={"Uy joy bilan taminlash"} procent={65} wgProcent={"65%"} procentText={"23.28%"} />

                </div>
                <img src={img3} alt="" className='card-image px-2 py-3' />
            </div>
            </Col>
        </div>
        <div>
            <Col className='card border-0'>
                <div>
                     <h3 className='card-title'><TfiStatsUp style={{width: "36px", height:"36px"}} /> Murojaatlar eng ko’p tushgan tuman/shaxar dinamikasi</h3>
                </div>
                <Table/>
            </Col>  
        </div>
        <div>
        <Col className='card border-0'>
        <div>
                     <h3 className='card-title'><LuLandmark  style={{width: "36px", height:"36px"}} />Hozirda murojatlari jarayondagi yuqori tashkilotlar</h3>
                </div>
                <Table/>
            </Col >
        </div>
        <div>
        <Col className='card border-0'>
        <div>
                     <h3 className='card-title'><TfiStatsUp style={{width: "36px", height:"36px"}} /> Murojaatlar eng ko’p tushgan tuman/shaxar dinamikasi</h3>
                </div>
                <Table/>
        </Col>
        </div>
    </div>

</div>
)
}

export default Home