import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import './Dashboard.css'
import Sidebar from '../components/Sidebar'
import Home from './Home'
import img from '../assets/Naqsh 2.png'

const Dashboard = () => {
  return (
    <div className='d-flex'>
        <Col className='sidebar'><Sidebar/></Col>
        <Col className='body'>
          <img
                src={img}
                className="d-inline-block naqsh align-top"
                alt="React Bootstrap logo"/>
          <div className='rel'>
            <Home/>
          </div>
        </Col>
    </div>
  )
}

export default Dashboard